from django import forms

from .models import Admin, Customer, Buyingproperty, Sellingproperty


class DateInput(forms.DateInput):
    input_type = "date"
class BuyingpropertyForm(forms.ModelForm):
    class Meta:
        model = Buyingproperty
        fields = "__all__"

class UpdateBuyingpropertyForm(forms.ModelForm):
    class Meta:
        model = Buyingproperty
        fields = "__all__"

class SellingpropertyForm(forms.ModelForm):
    class Meta:
        model = Sellingproperty
        fields = "__all__"
        labels = {"category":"Select Category"}

class AdminLoginForm(forms.ModelForm):
    class Meta:
        model = Admin
        fields = "__all__"
        widgets = {"password":forms.PasswordInput()}

class CustomerRegistrationForm(forms.ModelForm):
    class Meta:
        model = Customer
        fields = "__all__"
        widgets = {"dateofbirth":DateInput(),"password":forms.PasswordInput(),'fullname': forms.TextInput(attrs={'placeholder': 'Enter Full Name'}),'email': forms.TextInput(attrs={'placeholder': 'Enter Email Address'})}
