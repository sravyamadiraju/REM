from django.conf import settings
from django.conf.urls.static import static
from django.urls import path
from . import views

urlpatterns = [
    path('',views.index,name="index"),
    path('cusregistration',views.cusregistration,name="cusregistration"),
    path('cuslogin',views.cuslogin,name="cuslogin"),
    path('checkcuslogin',views.checkcuslogin,name="checkcuslogin"),
    path('cushome',views.cushome,name="cushome"),
    path('cusprofile',views.cusprofile,name="cusprofile"),
    path('cuschangepwd',views.cuschangepwd,name="cuschangepwd"),
    path('cusupdatepwd', views.cusupdatepwd, name="cusupdatepwd"),
    path('contact', views.contact, name="contact"),
    path('buypropertys', views.buypropertys, name="buypropertys"),
    path('cuslogout',views.cuslogout,name='cuslogout'),
    path('success.html', views.success, name='success'),
    path('adminlogin',views.adminlogin,name='adminlogin'),
    path('checkadminlogin',views.checkadminlogin,name="checkadminlogin"),
    path('adminhome',views.adminhome,name="adminhome"),
    path('payment.html',views.payment,name="payment"),
    path("updatebuyproperty",views.updatebuyingproperty,name="updatebuyproperty"),
    path("addsellingproperty",views.addsellingproperty,name="addsellingproperty"),
    path('viewcus',views.viewcustomers,name="viewcus"),
    path('viewbuypropertys',views.viewbuyingpropertys,name="viewbuypropertys"),
    path("deletecus/<int:cid>",views.deletecus,name="deletecus"),
    path('adminlogout', views.adminlogout, name='adminlogout'),

]

if settings.DEBUG:
        urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)

