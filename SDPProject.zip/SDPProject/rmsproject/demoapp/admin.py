from django.contrib import admin

from .models import Admin,Customer,Buyingproperty,Sellingproperty

admin.site.register(Admin)
admin.site.register(Customer)
admin.site.register(Buyingproperty)
admin.site.register(Sellingproperty)