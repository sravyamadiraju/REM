from django.db.models import Q
from django.shortcuts import render, redirect
from .forms import CustomerRegistrationForm,SellingpropertyForm,AdminLoginForm,BuyingpropertyForm,UpdateBuyingpropertyForm
from .models import Customer,Buyingproperty,Admin,Sellingproperty
from django.shortcuts import render
import razorpay
from django.contrib.auth.hashers import make_password
def index(request):
    return render(request,"index.html")

def cusregistration(request):
    form = CustomerRegistrationForm()
    if request.method == "POST":
        formdata = CustomerRegistrationForm(request.POST,request.FILES)
        if formdata.is_valid():
            formdata.save()
            msg="Customer Registered Successfully"
            return render(request, "cusregistration.html", {"cusform": form,"msg":msg})
        else:
            msg = "Failed to Register Customer"
            return render(request, "cusregistration.html", {"cusform": form, "msg": msg})
    return render(request,"cusregistration.html",{"cusform":form})

def cuslogin(request):
    return render(request,"cuslogin.html")

def checkcuslogin(request):
    uname = request.POST["cusername"]
    pwd = request.POST["cpassword"]

    flag = Customer.objects.filter(Q(username=uname) & Q(password=pwd))

    print(flag)

    if flag:
        cus = Customer.objects.get(username=uname)
        print(cus)
        request.session["cid"] = cus.id
        request.session["cname"] = cus.fullname
        return render(request, "cushome.html", {"cid": cus.id, "cname": cus.fullname})
    else:
        msg = "Login Failed"
        return render(request, "cuslogin.html", {"msg": msg})


def cushome(request):
    cid=request.session["cid"]
    cname=request.session["cname"]
    return render(request,"cushome.html",{"cid":cid,"cname":cname})

def cusprofile(request):
    cid=request.session["cid"]
    cname=request.session["cname"]
    auname=request.session["auname"]
    sellingpropertylist = Sellingproperty.objects.get(name=cname)
    cus = Customer.objects.get(id=cid)
    return render(request,"cusprofile.html",{"cid":cid,"cname":cname,"cus":cus,"auname":auname,"sellingpropertylist":sellingpropertylist})

def cuschangepwd(request):
    cid=request.session["cid"]
    cname=request.session["cname"]
    return render(request,"cuschangepwd.html",{"cid":cid,"cname":cname})

def cusupdatepwd(request):
    cid=request.session["cid"]
    cname=request.session["cname"]

    opwd=request.POST["opwd"]
    npwd=request.POST["npwd"]

    flag = Customer.objects.filter(Q(id=cid) & Q(password=opwd))

    if flag:
        Customer.objects.filter(id=cid).update(password=npwd)
        msg = "Password Updated Successfully"
        return render(request, "cuschangepwd.html", {"cid": cid, "cname": cname,"msg":msg})
    else:
        msg = "Old Password is Incorrect"
        return render(request, "cuschangepwd.html", {"cid": cid, "cname": cname,"msg":msg})


def cuslogout(request):
    return render(request,"cuslogin.html")

def adminlogin(request):
    return render(request,"adminlogin.html")

def checkadminlogin(request):
    uname = request.POST["ausername"]
    pwd = request.POST["apassword"]

    flag = Admin.objects.filter(Q(username__exact=uname) & Q(password__exact=pwd))
    print(flag)

    if flag:
        admin = Admin.objects.get(username=uname)
        print(admin)
        request.session["auname"] = admin.username
        return render(request, "adminhome.html", {"auname": admin.username})
    else:
        msg = "Login Failed"
        return render(request, "adminlogin.html", {"msg": msg})


def adminhome(request):
    auname=request.session["auname"]
    return render(request,"adminhome.html",{"auname":auname})


def updatebuyingproperty(request):
    auname = request.session["auname"]
    form = UpdateBuyingpropertyForm()
    if request.method == "POST":
        formdata = UpdateBuyingpropertyForm(request.POST)

        buypropertyid = formdata.data['id']
        buypropertyname = formdata.data['name']
        buypropertyloc = formdata.data['location']
        buypropertyprice = formdata.data['price']
        buypropertydim = formdata.data['dimensions']
        flag = Buyingproperty.objects.filter(id=buypropertyid)

        if flag:
            Buyingproperty.objects.filter(id=buypropertyid).update(name=buypropertyname,location=buypropertyloc,price=buypropertyprice,dimension=buypropertydim)
            msg="Buyingproperty Updated Successfully"
            return render(request, "updatebuyproperty.html", {"auname":auname,"buypropertyform": form,"msg":msg})
        else:
            msg = "Buyingproperty ID Not Found"
            return render(request, "updatebuyproperty.html", {"auname":auname,"buypropertyform": form, "msg": msg})

    return render(request,"updatebuyproperty.html",{"auname":auname,"buypropertyform":form})

def addsellingproperty(request):
    auname = request.session["auname"]
    form = SellingpropertyForm()
    if request.method == "POST":
        formdata = SellingpropertyForm(request.POST,request.FILES)
        if formdata.is_valid():
            formdata.save()
            msg="Sellingproperty Added Successfully"
            return render(request, "addsellingproperty.html", {"auname":auname,"sellingpropertyform": form,"msg":msg})
        else:
            msg = "Failed to Add Sellingproperty"
            return render(request, "addsellingproperty.html", {"auname":auname,"sellingpropertyform": form, "msg": msg})
    return render(request,"addsellingproperty.html",{"auname":auname,"sellingpropertyform":form})

def viewcustomers(request):
    auname=request.session["auname"]
    cuslist = Customer.objects.all()
    count = Customer.objects.count()
    return render(request,"viewcus.html",{"auname":auname,"cuslist":cuslist,"count":count})
def contact(request):
    return render(request,"contact.html")
def viewbuyingpropertys(request):
    auname=request.session["auname"]
    buypropertylist = Buyingproperty.objects.all()
    count = Buyingproperty.objects.count()
    return render(request,"viewbuypropertys.html",{"auname":auname,"buypropertylist":buypropertylist,"count":count})

def buypropertys(request):
    auname=request.session["auname"]
    sellingpropertylist = Sellingproperty.objects.all()
    count = Sellingproperty.objects.count()
    if request.method == "POST":
        name = request.POST.get('name')
        amount = 5000000

        client = razorpay.Client(
            auth=("rzp_test_yg0pTTcw7K03zy", "XldmPymrhsqNuEcSJjzbvVtz"))

        payment = client.order.create({'amount': amount, 'currency': 'INR',
                                       'payment_capture': '1'})
    return render(request,"buypropertys.html",{"auname":auname,"sellingpropertylist":sellingpropertylist,"count":count})

def deletecus(reequest,cid):
    Customer.objects.filter(id=cid).delete()
    return redirect("viewcus")
def payment(request):
    if request.method == "POST":
        name = request.POST.get('name')
        amount = 5000000

        client = razorpay.Client(
            auth=("rzp_test_yg0pTTcw7K03zy", "XldmPymrhsqNuEcSJjzbvVtz"))

        payment = client.order.create({'amount': amount, 'currency': 'INR',
                                       'payment_capture': '1'})
    return render(request, "payment.html")
def adminlogout(request):
    return render(request,"adminlogin.html")
def success(request):
    return render(request, "success.html")